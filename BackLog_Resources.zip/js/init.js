$(document).ready(function() {
        $('.parallax').parallax();
        $('#backitemTable').DataTable( {
                order: [[ 2, 'desc' ]]
            } );
            
        } );
        
        function hide(){
        	$('.button-collapse').sideNav('hide');
    	}